from flask import Flask, request, render_template

app = Flask(__name__)

# List of all common symptoms
SYMPTOMS_LIST = [
    "fever", "cold", "flu", "cough", "sore throat",
    "headache", "migraine", "body pain", "back pain", "joint pain",
    "vomiting", "diarrhea", "constipation", "acidity", "gas", "indigestion",
    "allergy", "rash", "itching", "shortness of breath", "wheezing",
    "insomnia", "anxiety", "stress", "fatigue", "dizziness", "low energy",
    "high blood pressure", "chest pain"
]

@app.route("/", methods=["GET", "POST"])
def home():
    drug = None
    error = None

    if request.method == "POST":
        symptoms_input = request.form.get("symptoms", "").lower()
        age = request.form.get("age", type=int)
        weight = request.form.get("weight", type=float)

        if not age or not weight:
            error = "Please enter both age and weight for accurate recommendations."
        else:
            drug = get_drug_recommendation(symptoms_input, age, weight)

    return render_template("index.html", drug=drug, symptoms=SYMPTOMS_LIST, error=error)

def get_drug_recommendation(symptoms, age, weight):
    # Drug database with base doses for adults
    drug_db = {
        "fever": {"name": "Paracetamol", "base_dose": 500, "meal": "After food"},
    "cold": {"name": "Cetirizine", "base_dose": 10, "meal": "After food"},
    "flu": {"name": "Oseltamivir", "base_dose": 75, "meal": "After food"},
    "cough": {"name": "Dextromethorphan", "base_dose": 10, "meal": "After food"},
    "sore throat": {"name": "Lozenges", "base_dose": 2, "meal": "As needed"},
    "headache": {"name": "Ibuprofen", "base_dose": 400, "meal": "After food"},
    "migraine": {"name": "Sumatriptan", "base_dose": 50, "meal": "After food"},
    "body pain": {"name": "Paracetamol", "base_dose": 500, "meal": "After food"},
    "back pain": {"name": "Diclofenac", "base_dose": 50, "meal": "After food"},
    "joint pain": {"name": "Naproxen", "base_dose": 250, "meal": "After food"},
    "vomiting": {"name": "Domperidone", "base_dose": 10, "meal": "Before food"},
    "diarrhea": {"name": "Loperamide", "base_dose": 4, "meal": "After food"},
    "constipation": {"name": "Lactulose", "base_dose": 15, "meal": "After food"},
    "acidity": {"name": "Omeprazole", "base_dose": 20, "meal": "Before food"},
    "gas": {"name": "Simethicone", "base_dose": 40, "meal": "After food"},
    "indigestion": {"name": "Ranitidine", "base_dose": 150, "meal": "After food"},
    "allergy": {"name": "Loratadine", "base_dose": 10, "meal": "After food"},
    "rash": {"name": "Hydrocortisone cream", "base_dose": "Apply thin layer", "meal": "Topical"},
    "itching": {"name": "Cetirizine", "base_dose": 10, "meal": "After food"},
    "shortness of breath": {"name": "Salbutamol inhaler", "base_dose": "2 puffs", "meal": "As needed"},
    "wheezing": {"name": "Budesonide inhaler", "base_dose": "2 puffs", "meal": "As needed"},
    "insomnia": {"name": "Melatonin", "base_dose": 5, "meal": "Before bedtime"},
    "anxiety": {"name": "Alprazolam", "base_dose": 0.25, "meal": "After food"},
    "stress": {"name": "Ashwagandha", "base_dose": 500, "meal": "After food"},
    "fatigue": {"name": "Vitamin B12", "base_dose": 1000, "meal": "After food"},
    "dizziness": {"name": "Betahistine", "base_dose": 16, "meal": "After food"},
    "low energy": {"name": "Iron supplement", "base_dose": 325, "meal": "After food"},
    "high blood pressure": {"name": "Amlodipine", "base_dose": 5, "meal": "After food"},
    "chest pain": {"name": "Nitroglycerin", "base_dose": "0.3 mg", "meal": "As needed"}
    }

    # Search for the symptom
    if symptoms in drug_db:
        drug_info = drug_db[symptoms]

        # Adjust dose based on age and weight
        adjusted_dose = calculate_dose(drug_info["base_dose"], age, weight)

        return {
            "name": drug_info["name"],
            "dose": f"{adjusted_dose}mg",
            "meal": drug_info["meal"]
        }

    # Default case if no symptom is found
    return {"name": "Consult a doctor", "dose": "N/A", "meal": "N/A"}

def calculate_dose(base_dose, age, weight):
    # Dose adjustment rules:
    if age <= 12:
        return base_dose * 0.5  # Half dose for children under 12
    elif weight <= 50:
        return base_dose * 0.75  # 75% dose for low body weight
    else:
        return base_dose  # Full dose for adults with normal weight

if __name__ == "__main__":
    app.run(debug=True)
